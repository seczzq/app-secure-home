adb devices
adb connect 127.0.0.1:62001


adb logcat